This file contains a list of urls that we test to make sure our build pipelines can succeed. 
We verify that the site is available in general and that the http and https request pipelines work.

- [HTTP Pipeline](http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-4.6.xsd)
- [HTTPS Pipeline](https://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-4.6.xsd)
