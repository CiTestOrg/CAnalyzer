# The reason this file exists is that SONAR expects either BOTH src/test/java AND src/test/groovy to exist, or NONE
# of these two.