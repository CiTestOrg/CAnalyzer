package liquibase.changelog;

import liquibase.serializer.LiquibaseSerializable;

public interface ChangeLogChild extends LiquibaseSerializable {
}
