package liquibase;

public interface SingletonObject {
}
